import { Scoreboard } from "./Scoreboard";
import { Scorecard } from "./Scorecard";
import { UsersData } from "./UsersData";

function App() {
  return (
    <div>
      <Scoreboard/>
      {/* <Scorecard/> */}
      <UsersData/>
    </div>
  )
}

export default App
