export function About(){
    return (
        <div>
            <h1>Welcome to About</h1>
            <p>this is about page</p>
            <h1>Our Vision</h1>
            <p>this is our vision</p>
            <h1>Our Mission</h1>
            <p>this is our mission</p>
        </div>
    )
}