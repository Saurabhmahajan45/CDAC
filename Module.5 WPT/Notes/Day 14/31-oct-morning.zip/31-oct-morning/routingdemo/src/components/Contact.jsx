export function Contact(){
    return (
        <div>
            <h1>Welcome to Contact</h1>
            <p>+91-999911111, mail: admin@mail.com</p>
        </div>
    )
}