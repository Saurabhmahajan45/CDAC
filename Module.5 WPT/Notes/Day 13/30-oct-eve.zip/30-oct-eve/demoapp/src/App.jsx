import {Demo} from './Demo';

function App() {
  return (
    <div>
      <h1>Hello World</h1>
      {/* <Demo></Demo> */}
      <Demo/>
    </div>
  )
}

export default App
