exports.sum = function(a,b){
    return a+b;
}

exports.product = function(a,b){
    return a*b;
}