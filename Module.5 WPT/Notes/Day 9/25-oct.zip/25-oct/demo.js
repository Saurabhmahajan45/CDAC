const myModule = require('./mymodule.js');

var rs = myModule.sum(2,4);

console.log('sum is', rs);