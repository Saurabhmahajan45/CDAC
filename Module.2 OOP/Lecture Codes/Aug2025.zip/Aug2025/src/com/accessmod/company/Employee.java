package com.accessmod.company;

public class Employee {
	protected String dept;
	
	protected void show() {
		System.out.println("Protected method : show()");
	}

}
