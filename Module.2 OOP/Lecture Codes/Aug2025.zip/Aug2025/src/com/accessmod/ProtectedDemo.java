package com.accessmod;

import com.accessmod.hr.Manager;

public class ProtectedDemo {
	
	public static void main(String[] args) {
		Manager mg = new Manager("Training");
		mg.display();
	}

}
