package com.cdac;//Userdefined package

import java.util.*;//Inbuilt package

public class TestDemo {

	public static void main(String[] args) {
		System.out.println("Hello, World!");
		System.out.println("Hello, World!");
		System.out.println("Hello, World!");
		}

}
