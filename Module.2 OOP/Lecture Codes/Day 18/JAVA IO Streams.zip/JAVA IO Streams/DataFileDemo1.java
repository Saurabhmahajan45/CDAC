
import java.io.*;
//5. write bytes from a primitive data

public class DataFileDemo1{
    public static void main(String[] args) {
		
		try{
			
			FileOutputStream fout = new FileOutputStream("doutput.txt");
			DataOutputStream dout = new DataOutputStream(fout);
			
			dout.writeInt(101);
			dout.writeDouble(999.88);
			dout.writeUTF("Java streams");
			
			dout.close();
			fout.close();
			System.out.println("Data printed !!!");
			
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
