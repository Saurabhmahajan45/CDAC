
import java.io.*;
//5. write bytes from a primitive data

public class DataFileDemo2{
    public static void main(String[] args) {
		
		try{
			
			FileInputStream fin = new FileInputStream("doutput.txt");
			DataInputStream din = new DataInputStream(fin);
			
			int id = din.readInt();
			double n = din.readDouble();
			String s = din.readUTF();
			
			System.out.println(id);
			System.out.println(n);
			System.out.println(s);
			
			din.close();
			fin.close();
			
			
					
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
