
import java.io.*;
//4. Read bytes from a file buffer

public class BufferedFileDemo2{
    public static void main(String[] args) {
		
		try{
			
			FileInputStream fin = new FileInputStream("boutput.txt");
			BufferedInputStream bin = new BufferedInputStream(fin);
			
			int i;
			while((i = bin.read()) != -1){
				System.out.print((char)i);
			}
			
			bin.close();
			fin.close();
						
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
