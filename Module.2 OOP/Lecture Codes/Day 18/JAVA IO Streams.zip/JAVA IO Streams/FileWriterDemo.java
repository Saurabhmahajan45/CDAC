import java.io.*;


public class FileWriterDemo{
    public static void main(String[] args) {
		
		try{
			
			FileWriter fw = new FileWriter("Write.txt");	
			fw.write("This is the text to write");
			
			fw.close();
			System.out.println("Done!!");
					
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
