
import java.io.*;
//2. Read bytes from a file

public class BufferedFileDemo1{
    public static void main(String[] args) {
		
		try{
			FileOutputStream fout = new FileOutputStream("boutput.txt");
			BufferedOutputStream bout = new BufferedOutputStream(fout);
			
			String s = "Ho gaya learning !!!!";
			bout.write(s.getBytes());
			
			bout.close();
			fout.close();
			
			
			
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
