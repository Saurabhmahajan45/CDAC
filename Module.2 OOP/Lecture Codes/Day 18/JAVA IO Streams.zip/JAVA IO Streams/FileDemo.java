
import java.io.*;

public class FileDemo{
    public static void main(String[] args) {
		
		File obj = new File("myfile.txt");
		System.out.println("File created");

    }
}
