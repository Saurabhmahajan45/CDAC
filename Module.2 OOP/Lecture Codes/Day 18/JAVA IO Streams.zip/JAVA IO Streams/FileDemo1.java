
import java.io.*;
//1. Write bytes to a file

public class FileDemo1{
    public static void main(String[] args) {
		
		try{
			FileOutputStream fout = new FileOutputStream("output2.dat");
			String text = "Hello File handling programs 23456!!!";
			fout.write(text.getBytes());
			fout.close();
			System.out.println("Data updated successfully!");
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
