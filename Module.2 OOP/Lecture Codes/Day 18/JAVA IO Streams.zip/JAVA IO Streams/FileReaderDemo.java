import java.io.*;


public class FileReaderDemo{
    public static void main(String[] args) {
		
		try{
			FileReader fr1 = new FileReader("Write.txt");
			
			int i;
			while((i = fr1.read()) != -1){
				System.out.print((char)i);
			}
			
			
			//fr1.close();
			
					
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
