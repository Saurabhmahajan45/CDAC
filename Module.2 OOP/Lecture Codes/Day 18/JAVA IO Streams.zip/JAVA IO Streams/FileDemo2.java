
import java.io.*;
//2. Read bytes from a file

public class FileDemo2{
    public static void main(String[] args) {
		
		try{
			
			FileInputStream fin = new FileInputStream("output.txt");
			int i;
			while((i = fin.read()) != -1){
				System.out.print((char)i);
			}
			fin.close();
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
    }
}
